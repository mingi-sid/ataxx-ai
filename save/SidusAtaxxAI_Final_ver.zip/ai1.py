import sys
import random
import ataxx
import ataxx.players

if __name__ == "__main__":
    logfile_name = __file__[:-3] + 'log.txt'
    f = open(logfile_name, 'a')

    input_str = sys.stdin.read()

    # 입력 예시
    # READY 1234567890.1234567 (입력시간)
    # "OK" 를 출력하세요.
    if input_str.startswith("READY"):
        f.write("OK\n")
        f.close()
        # 출력
        sys.stdout.write("OK")

    # 입력 예시
    # PLAY
    # 2 0 0 0 0 0 1
    # 0 0 0 0 0 0 0
    # 0 0 0 0 0 0 0
    # 0 0 0 0 0 0 0
    # 0 0 0 0 0 0 0
    # 0 0 0 0 0 0 0
    # 1 0 0 0 0 0 2
    # 1234567890.1234567 (입력시간)

    # AI의 액션을 출력하세요.
    # 출력 예시 : "0 0 2 2"
    elif input_str.startswith("PLAY"):
        player = __file__[2]
        board = []
        actions = {} # { key: piece(start position), value: list of position(destination position) }

        # make board
        input_lines = input_str.split("\n")
        for i in range(7):
            board.append([int(x) for x in input_lines[i+1].split(" ")])
        for row in board:
            f.write(' '.join([str(x) for x in row]))
            f.write('\n')

        for row in range(7):
            for col in range(7):
                if board[row][col] == int(player):
                    moveable_positions = []
                    for i in range(max(row-2, 0), min(row+3, 7)):
                        for j in range(max(col-2, 0), min(col+3, 7)):
                            if board[i][j] == 0:
                                moveable_positions.append((i, j))
                    if moveable_positions:
                        actions[(row, col)] = moveable_positions
        
        ataxx_board = ataxx.Board()
        for x in range(7):
            for y in range(7):
                ataxx_board.set(x, y, {2:ataxx.WHITE,1:ataxx.BLACK,0:ataxx.EMPTY}[board[x][y]])
        move = ataxx.players.alphabeta(ataxx_board, -999999, 999999, 3)
        if move.is_single():
            position = move.to_x, move.to_y
            #f.write(str(position))
            piece = None
            #f.write(str(move_from))
            for move_from in actions.keys():
                if position in actions[move_from]:
                    piece = move_from
                    break
        else:
            piece = move.fr_x, move.fr_y
            position = move.to_x, move.to_y
        
        f.write(f"{piece[0]} {piece[1]} {position[0]} {position[1]}" + '\n')

        # 출력
        sys.stdout.write(f"{piece[0]} {piece[1]} {position[0]} {position[1]}")
